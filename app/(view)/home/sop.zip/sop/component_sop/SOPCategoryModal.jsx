'use client';

import React, { useMemo, useState } from 'react';

import AppModal from '@/app/(view)/component_shared/AppModal';
import AppTable from '@/app/(view)/component_shared/AppTable';
import AppButton from '@/app/(view)/component_shared/AppButton';
import AppSpace from '@/app/(view)/component_shared/AppSpace';
import AppTypography from '@/app/(view)/component_shared/AppTypography';
import AppTooltip from '@/app/(view)/component_shared/AppTooltip';

import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';

import SOPCategoryFormModal from './SOPCategoryFormModal';

export default function SOPCategoryModal({ open, categories, onClose, onSave, onDelete }) {
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const activeList = useMemo(() => (categories || []).filter((c) => c.is_active), [categories]);

  const columns = useMemo(
    () => [
      {
        title: 'NAMA KATEGORI',
        dataIndex: 'name',
        key: 'name',
        render: (text, record) => (
          <div className='min-w-0'>
            <AppTypography.Text size={13} weight={800} className='text-slate-900 block truncate' title={text}>
              {text}
            </AppTypography.Text>
            <AppTypography.Text size={12} tone='muted' className='text-slate-500 block'>
              {record.description || '—'}
            </AppTypography.Text>
          </div>
        ),
      },
      {
        title: 'AKSI',
        key: 'action',
        width: 140,
        align: 'center',
        render: (_, record) => (
          <AppSpace size='sm'>
            <AppTooltip title='Edit'>
              <AppButton
                aria-label='Edit'
                variant='ghost'
                icon={<EditOutlined />}
                onClick={() => {
                  setEditing(record);
                  setFormOpen(true);
                }}
              />
            </AppTooltip>

            <AppTooltip title='Hapus'>
              <AppButton
                aria-label='Hapus'
                danger
                icon={<DeleteOutlined />}
                onClick={() => {
                  const ok = window.confirm('Apakah Anda yakin ingin menghapus kategori ini?');
                  if (ok) onDelete?.(record.key);
                }}
              />
            </AppTooltip>
          </AppSpace>
        ),
      },
    ],
    [onDelete]
  );

  return (
    <>
      <AppModal open={open} title='Manajemen Kategori SOP' onCancel={onClose} footer={null} destroyOnClose width={900}>
        <div className='flex flex-col gap-3'>
          <div className='flex items-center justify-between gap-2 flex-wrap'>
            <AppTypography.Text tone='secondary'>
              Total kategori aktif: <b>{activeList.length}</b>
            </AppTypography.Text>

            <AppButton
              variant='primary'
              icon={<PlusOutlined />}
              onClick={() => {
                setEditing(null);
                setFormOpen(true);
              }}
            >
              Tambah Kategori
            </AppButton>
          </div>

          <AppTable rowKey='key' dataSource={activeList} columns={columns} pagination={{ pageSize: 10 }} />
        </div>
      </AppModal>

      <SOPCategoryFormModal
        open={formOpen}
        category={editing}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
        }}
        onSave={async (payload) => {
          await onSave?.(payload);
          setFormOpen(false);
          setEditing(null);
        }}
      />
    </>
  );
}
