-- AlterTable
ALTER TABLE `kategori_cuti` ADD COLUMN `pengurangan_kouta` BOOLEAN NOT NULL DEFAULT true;
