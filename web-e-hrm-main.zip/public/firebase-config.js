self.__FIREBASE_CONFIG__ = {
  "apiKey": "",
  "authDomain": "",
  "projectId": "",
  "storageBucket": "",
  "messagingSenderId": "",
  "appId": ""
};
self.__FIREBASE_VAPID_KEY__ = "";
