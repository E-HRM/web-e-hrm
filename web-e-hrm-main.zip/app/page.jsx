import Login from "./(view)/auth/login/page";

export default function Home() {
  return <Login />;
}
