import LoginContent from './LoginContent';

export default function Page() {
  return <LoginContent />;
}
  